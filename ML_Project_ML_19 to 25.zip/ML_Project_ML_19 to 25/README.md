# ML_Project_1_11
Porject from Machine Learning(1_11) sessions 19-32
